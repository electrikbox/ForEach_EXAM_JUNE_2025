package com.cocktailbar.backend.DTO;

public class LoginResponse {
    private String token;
    private long expiresIn;

    public LoginResponse() {}

    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public long getExpiresIn() {
        return expiresIn;
    }
    public void setExpiresIn(long expiresIn) {
        this.expiresIn = expiresIn;
    }
} 